class userSelectors {
    constructor(page) {
      this.page = page;
      this.userProfileButton = this.page.locator('button[aria-label="Open user profile"]');
      this.logoutButton = this.page.locator('button.k-button-clear.k-button-clear-base.k-rounded-md');
    }
  }
  
  module.exports = userSelectors;