// constants/loginDetails.js
const loginDetails = {
  LOGIN_EMAIL: "alexandru.dancesc+ERIC_WRIGHT_CIVIL_ENGINEERING_LIMITED@amdaris.com",
  LOGIN_PASSWORD: "",
};

module.exports = loginDetails;
